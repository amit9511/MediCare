SELECT ([YEAR]), 
       SUM([Part D Prescribers]) AS 'Total of Part D Prescribers Destination Table' ,
       SUM([Part D Opioid Prescribers])AS 'Total of Part D Opioid Prescribers Destination Table',
       SUM([Opioid Claims]) AS 'Total of Opioid Claims Destination Table',
       SUM([Extended Release Opioid Claims])AS 'Total of Extended Release Opioid Claims Destination Table',
       SUM([Overall Claims])AS 'Total of Overall Claims Destination Table' FROM 
	   [MediCare].[dbo].[Destination Table]
	   GROUP BY ([YEAR]) ;

SELECT ([YEAR]), 
       SUM([Part D Prescribers]) AS 'Total of Part D Prescribers National ID ' ,
       SUM([Part D Opioid Prescribers])AS 'Total of Part D Opioid Prescribers National ID',
       SUM([Opioid Claims]) AS 'Total of Opioid Claims National ID',
       SUM([Extended Release Opioid Claims])AS 'Total of Extended Release Opioid Claims National ID',
       SUM([Overall Claims])AS 'Total of Overall Claims National ID' FROM 
	   [MediCare].[dbo].[National Total Table]
	   GROUP BY ([YEAR]) ;